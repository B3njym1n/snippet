var searchData=
[
  ['resetcolor',['resetColor',['../rogueutil_8h.html#af76a7b1c7368760dafd6ff48352c3544',1,'rogueutil.h']]],
  ['rutil_5fprint',['rutil_print',['../rogueutil_8h.html#a159c051c58e656e0d649300552648855',1,'rogueutil.h']]]
];
