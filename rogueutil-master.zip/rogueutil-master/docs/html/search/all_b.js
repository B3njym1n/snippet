var searchData=
[
  ['tcols',['tcols',['../rogueutil_8h.html#ab81edfbfd6a1a844399abe7227db23a4',1,'rogueutil.h']]],
  ['trows',['trows',['../rogueutil_8h.html#a5469536cf5b24714472083b9697381b6',1,'rogueutil.h']]]
];
