var searchData=
[
  ['torch',['TORCH',['../example_8c.html#ad96bf473a06bef043515218474dadd6b',1,'example.c']]]
];
