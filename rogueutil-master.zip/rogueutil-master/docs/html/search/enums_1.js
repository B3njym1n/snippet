var searchData=
[
  ['key_5fcode',['key_code',['../rogueutil_8h.html#a2448bb1a2a4ecaece867a981e5b4f3ea',1,'rogueutil.h']]]
];
