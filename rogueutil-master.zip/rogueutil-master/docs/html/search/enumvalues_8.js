var searchData=
[
  ['white',['WHITE',['../rogueutil_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba283fc479650da98250635b9c3c0e7e50',1,'rogueutil.h']]]
];
