var searchData=
[
  ['color_5fcode',['color_code',['../rogueutil_8h.html#aa107bc1c2d86eae3e234ca343d6bd856',1,'rogueutil.h']]]
];
