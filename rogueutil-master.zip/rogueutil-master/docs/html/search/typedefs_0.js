var searchData=
[
  ['color_5fcode',['color_code',['../rogueutil_8h.html#ae264b930c0ad3c485c985d7024541a6d',1,'rogueutil.h']]]
];
