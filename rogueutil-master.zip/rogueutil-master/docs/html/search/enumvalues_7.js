var searchData=
[
  ['red',['RED',['../rogueutil_8h.html#a06fc87d81c62e9abb8790b6e5713c55baf80f9a890089d211842d59625e561f88',1,'rogueutil.h']]]
];
