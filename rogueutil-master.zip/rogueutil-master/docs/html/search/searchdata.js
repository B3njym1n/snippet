var indexSectionsWithContent =
{
  0: "acghklmnprst",
  1: "r",
  2: "acghklmnprst",
  3: "ck",
  4: "ck",
  5: "r",
  6: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Macros",
  6: "Pages"
};

