var searchData=
[
  ['magenta',['MAGENTA',['../rogueutil_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba56926c820ad72d0977e7ee44d9916e62',1,'rogueutil.h']]]
];
