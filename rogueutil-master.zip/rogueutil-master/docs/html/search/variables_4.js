var searchData=
[
  ['torch',['torch',['../example_8c.html#a0e3b1f971357b7881685fb26f2917b38',1,'example.c']]]
];
