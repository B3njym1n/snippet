var searchData=
[
  ['nb_5fgetch',['nb_getch',['../rogueutil_8h.html#af2ccacf562957f43cea8833ff1e0d965',1,'rogueutil.h']]]
];
