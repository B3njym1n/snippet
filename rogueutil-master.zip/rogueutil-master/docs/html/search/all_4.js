var searchData=
[
  ['kbhit',['kbhit',['../rogueutil_8h.html#a97e9b1fe8d4c010474637a654aad6566',1,'rogueutil.h']]],
  ['key_5fcode',['key_code',['../rogueutil_8h.html#a2448bb1a2a4ecaece867a981e5b4f3ea',1,'key_code():&#160;rogueutil.h'],['../rogueutil_8h.html#a1f120cc37b9f1d09d366e371578d0826',1,'key_code():&#160;rogueutil.h']]]
];
